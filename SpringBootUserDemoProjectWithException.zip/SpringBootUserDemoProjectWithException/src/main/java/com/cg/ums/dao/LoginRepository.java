package com.cg.ums.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ums.dto.Login;

@Repository("loginJpaDao")
@Transactional
public interface LoginRepository extends JpaRepository<Login, String> {
	
	@Query("SELECT userList FROM Login userList")
	public ArrayList<Login> getAllUsers();
	
	
	@Query("SELECT user FROM Login user WHERE user.username = :unm")
	public Login getUserByUsername(@Param("unm")String unm);
	
	@Modifying
	@Query("DELETE FROM Login log WHERE log.username=:unm")
	public void deleteUserByUsername(@Param("unm")String unm);
	
	@Modifying
	@Query("UPDATE Login log SET log.userPassword=:pw WHERE log.username=:nm")
	public void updateUserInfo(@Param("pw")String pwd, @Param("nm")String umn);
}
