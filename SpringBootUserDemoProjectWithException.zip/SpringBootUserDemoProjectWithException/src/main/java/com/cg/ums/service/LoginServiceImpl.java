package com.cg.ums.service;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ums.dao.LoginRepository;
import com.cg.ums.dto.Login;
@Service
@Transactional
public class LoginServiceImpl implements LoginService {
	@Autowired
	LoginRepository loginDao;

	@Override
	public ArrayList<Login> getAllUsers() {
		// TODO Auto-generated method stub
		return loginDao.getAllUsers();
	}

	@Override
	public Login addUser(Login log) {
		// TODO Auto-generated method stub
		return loginDao.save(log);
	}

	@Override
	public Login getUserByUserName(String unm) {
		// TODO Auto-generated method stub
		//return loginDao.getOne(unm);
		return loginDao.getUserByUsername(unm);
	}

	@Override
	public void deleteUserByUsername(String unm) {
		// TODO Auto-generated method stub
		loginDao.deleteUserByUsername(unm);
		
	}

	@Override
	public void updateUserInfo(String pwd, String umn) {
		loginDao.updateUserInfo(pwd, umn);
		
	}
	
	
}
