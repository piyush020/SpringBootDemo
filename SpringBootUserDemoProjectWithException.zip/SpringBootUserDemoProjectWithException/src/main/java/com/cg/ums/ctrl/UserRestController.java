package com.cg.ums.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ums.dto.Login;
import com.cg.ums.exception.UserNotFoundException;
import com.cg.ums.service.LoginService;

@RestController
public class UserRestController {
	@Autowired
	LoginService loginService;

	@RequestMapping(value = "/showAllUsers", method = RequestMethod.GET, headers = "Accept=application/json")
	public ArrayList<Login> showAllUsers() {
		System.out.println("in user rest controller");
		return loginService.getAllUsers();
	}

	@PostMapping(value = "/addUser", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	public Login createUser(@RequestBody Login log) {
		loginService.addUser(log);
		Login lgg = loginService.getUserByUserName(log.getUsername());
		return lgg;
	}
	
	@DeleteMapping(value="/deleteUser/{uid}",
			headers="Accept=application/json")
	public void deleteUser(@PathVariable("uid")String unm) {
		loginService.deleteUserByUsername(unm);
		System.out.println("Data deleted");
	}
	
	@PutMapping(value="/user/update/",
			consumes=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public void updateUser(@RequestBody Login log) {
		loginService.updateUserInfo(log.getUserPassword(), log.getUsername());
		System.out.println("Data updated in the table");
	}
	
	@GetMapping(value="searchUser/{uid}")
	public Login searchUserById(@PathVariable("uid")String unm) throws UserNotFoundException{
		Login lgg = loginService.getUserByUserName(unm);
		if(lgg==null) {
			throw new UserNotFoundException("No User found with this id "+ unm);
		}else {
			return lgg;
		}
	}
}
