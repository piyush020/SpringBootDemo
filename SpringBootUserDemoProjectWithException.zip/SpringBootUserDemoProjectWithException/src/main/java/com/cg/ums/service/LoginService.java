package com.cg.ums.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.cg.ums.dto.Login;

@Service
public interface LoginService {
	
	public ArrayList<Login> getAllUsers();
	
	public Login addUser(Login log);
	
	public Login getUserByUserName(String unm);
	
	public void deleteUserByUsername(String unm);
	
	public void updateUserInfo(String pwd, String umn);
}
