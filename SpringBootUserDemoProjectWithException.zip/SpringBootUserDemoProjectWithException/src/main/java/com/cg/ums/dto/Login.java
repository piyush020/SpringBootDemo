package com.cg.ums.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;


@Entity
@Table(name="cg_users")
public class Login {
	
	//@Pattern(regexp="[A-Z][a-z]+")
	@Id
	@Column(name="user_name", length=20)
	private String username;
	
	@Column(name="password")
	private String userPassword;

	@Override
	public String toString() {
		return "Login [username=" + username + ", userPassword=" + userPassword + "]";
	}

	public Login(String username, String userPassword) {
		super();
		this.username = username;
		this.userPassword = userPassword;
	}

	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
}
